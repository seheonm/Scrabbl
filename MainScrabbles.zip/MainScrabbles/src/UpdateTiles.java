/**
 * This class updates the tiles
 */

import javafx.event.Event;
import javafx.event.EventType;

public class UpdateTiles extends Event {

    Position pos;
    Tile tile;
    boolean reset;

    static final EventType<UpdateTiles> UPDATE_TILES =
            new EventType<>(Event.ANY, "DROP_EVENT");

    //update the tiles after a play or move
    public UpdateTiles(Position pos, Tile letter, boolean reset) {
        super(UPDATE_TILES);
        this.pos = pos;
        this.tile = letter;
        this.reset = reset;
    }

}
