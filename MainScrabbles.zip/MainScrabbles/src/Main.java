/**
 * Marina Seheon
 * Project 3 CS351L
 * This is the main class for the scrabble GUI
 */

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

import java.io.*;

public class Main extends Application {
    private Player currentPlayer;
    private TilesManager tileManager;
    private Board board;
    private Controller controller;
    private Dictionary dict;
    public final static boolean DEBUG_PRINT = false;
    private final static String LETTER_DIS =
            "default_letter_distributions.txt";
    private final static String DEFAULT_BOARD = "default_board.txt";

    public Main() {
        currentPlayer = null;
        tileManager = null;
        board = null;
        controller = null;
        dict = null;
    }

    /**
     * Initiate the game sequence
     */
    private void startGame() {
        currentPlayer = null;
        controller.initialize();
        try {
            tileManager.initialize(new BufferedReader(new FileReader
                    (LETTER_DIS)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            board.initialize(new BufferedReader
                    (new FileReader(DEFAULT_BOARD)), tileManager);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        HumanPlayer humanPlayer =
                new HumanPlayer(tileManager,board,controller.getPlayerHand());
        controller.setupForUserPlayer(humanPlayer, dict);
        ComputerPlayer computerPlayer1 =
                new ComputerPlayer(tileManager, board, controller.
                        getComputerHand());

        while (currentPlayer == null) {
            Tile playerLetter = tileManager.drawOne();
            Tile computerLetter = tileManager.drawOne();

            if (playerLetter.letter < computerLetter.letter
                    || (playerLetter.isBlank() && !computerLetter.isBlank())){
                currentPlayer = humanPlayer;
            } else if (computerLetter.letter < playerLetter.letter
                    || (computerLetter.isBlank() && !playerLetter.isBlank())){
                currentPlayer = computerPlayer1;
            }

            tileManager.putBack(playerLetter);
            tileManager.putBack(computerLetter);
        }

        AnimationTimer timer = new AnimationTimer() {
            private Long start = null;

            @Override
            public void handle(long now) {
                if (start == null) {
                    start = now;
                }
                if (currentPlayer.takeTurn(dict) == 0) {
                    if (currentPlayer.isHandEmpty()) {
                        controller.updateScore(currentPlayer.
                                getLastWordPlayedScore(), currentPlayer);
                        this.stop();
                        int computerScore = controller.getTopScore();
                        int playerScore = controller.getBottomScore();
                        computerScore -=computerPlayer1.getLeftoverTileScore();
                        playerScore -= humanPlayer.getLeftoverTileScore();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Game Over");
                        if (computerScore > playerScore) {
                            alert.setHeaderText("You lost to the computer");
                        } else if (playerScore > computerScore) {
                            alert.setHeaderText("You beat the computer!");
                        } else {
                            alert.setHeaderText("You tied with the computer");
                        }
                        alert.getDialogPane().setMinSize(Region.USE_PREF_SIZE,
                                Region.USE_PREF_SIZE);
                        alert.setContentText("Computer Score: " +computerScore+
                                " Player Score: " + playerScore +
                                " Would you like to play again?");
                        ButtonType yes = new ButtonType("Yes");
                        ButtonType no = new ButtonType("No");
                        alert.getButtonTypes().setAll(yes, no);
                        alert.setOnHidden(dialogEvent -> {
                            ButtonType result =((Alert)dialogEvent.getSource())
                                    .getResult();
                            if (result == yes) {
                                startGame();
                            } else {
                                Platform.exit();
                            }
                        });
                        Platform.runLater(alert::showAndWait);

                        if (DEBUG_PRINT) {
                            System.out.println("Game took " +
                                    (System.nanoTime() - start) / 1000000 +
                                    "ms");
                        }
                    } else {
                        controller.updateScore(
                                currentPlayer.getLastWordPlayedScore(),
                                currentPlayer);
                        currentPlayer = (currentPlayer == humanPlayer)
                                ? computerPlayer1
                                : humanPlayer;
                    }
                }
            }
        };
        timer.start();
    }

    /**Launch the screen and start the game
     * @param args input from the command line
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * This is the launch method used by fxml to initialize the view
     * @param primaryStage the primary window created
     */
    @Override
    public void start(Stage primaryStage) {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("sample.fxml"));
        Parent root;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Could not read fxml file");
            return;
        }

        controller = loader.getController();

        Scene scene = new Scene(root);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Scrabble Game");
        primaryStage.setScene(scene);

        dict = Dictionary.createDict(Dictionary.DictionaryType.DAWG);
        try {
            dict.insert(new BufferedReader(
                    new FileReader("dictionary.txt")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        tileManager = new TilesManager();
        board = new Board(controller.getBoard());

        startGame();
        primaryStage.show();
    }
}
