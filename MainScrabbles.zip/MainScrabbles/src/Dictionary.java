/**
 * This class is the dictionary.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

public abstract class Dictionary {
    protected Word root;

    public enum DictionaryType {
        DAWG, TRIE
    }

    public static Dictionary createDict(DictionaryType type) {
        switch (type) {
            case DAWG:
                return new Implement();
            case TRIE:
                return new Transition();
        }

        return new Implement();
    }

    abstract public boolean search(String word);

    abstract public void insert(BufferedReader br);

    public Word getRootNode() {
        return root;
    }
}

/**
 * This class implements the dictionary
 */
class Implement extends Dictionary {
    private Map<ImplementNode, ImplementNode> equivalenceClass;
    private Set<Character> charSet;
    private int transitionCount;

    public Implement() {
        root = new ImplementNode(false);
        equivalenceClass = new HashMap<>();
        charSet = new TreeSet<>();
    }


    /**
     * Get the longest word that can be made from the current word
     * @param longWord the word to be checked against
     * @return String for the longest word
     */
    private String determineLongestPrefix(String longWord) {
        ImplementNode node = (ImplementNode)root;
        int i;
        for (i = 0; i < longWord.length(); i++) {
            if (node.hasTransition(longWord.charAt(i))) {
                node = node.transition(longWord.charAt(i));
            }
            else {
                break;
            }
        }

        return longWord.substring(0, i);
    }

    /**
     * Get the first node that has multiple outgoing transitions
     * @param startNode where the node starts
     * @param transition object containing possible chaining of letters to
     *                  make a valid word
     * @return map for the node with most transitions
     */
    private Map<String, Object> getFirstMultipleTransition(ImplementNode startNode, String transition) {
        ImplementNode temp = startNode;
        int i = 0;
        for (; i < transition.length(); i++) {
            char curr = transition.charAt(i);
            if (temp.hasTransition(curr)) {
                temp = temp.transition(curr);
            } else {
                temp = null;
            }

            if (temp == null || temp.hasMultipleIncomingTrans()) {
                break;
            }
        }

        Map<String, Object> map = new HashMap<>(2);
        map.put("charIndex", (temp == startNode || i == transition.length() ? null : i));
        map.put("multipleNode", (temp == startNode || i == transition.length() ? null : temp));

        return map;
    }

    /**
     * Remove the transition from the original word
     * @param transStr the transitions string
     */
    private void removeTransitionPath(String transStr) {
        ImplementNode temp = (ImplementNode)root;

        for (int i = 0; i < transStr.length(); i++) {
            temp = temp.transition(transStr.charAt(i));
            if (equivalenceClass.get(temp) == temp) {
                equivalenceClass.remove(temp);
            }
            temp.clearHash();
        }
    }

    /**
     * FInish off a transition when no more letters can be added
     * @param pivotNode the starting node
     * @param transToNode the transition object
     * @param trans the transition string
     */
    private void cloneTransitionPath(ImplementNode pivotNode,
                                     String transToNode, String trans) {
        ImplementNode lastNode = pivotNode.transition(trans);
        ImplementNode lastCloned = null;
        char lastLabelChar = '\0';

        for (int i = trans.length(); i >= 0; i--) {
            String currentString = (i > 0 ? trans.substring(0, i) : null);
            ImplementNode currentTarget =
                    (i > 0 ? pivotNode.transition(currentString) : pivotNode);
            ImplementNode cloned;

            if (i == 0) {
                String transToNodeParent = transToNode.substring(0,
                        transToNode.length() - 1);
                cloned = pivotNode.clone((ImplementNode)root.transition
                        (transToNodeParent), transToNode.charAt
                        (transToNode.length() - 1));
            }
            else {
                cloned = currentTarget.clone();
            }

            transitionCount += cloned.getTransitionCount();

            if (lastCloned != null) {
                cloned.changeTransition(lastLabelChar, lastNode, lastCloned);
            }
            lastCloned = cloned;
            lastLabelChar = (i > 0 ? trans.charAt(i - 1) : '\0');
        }
    }

    /**
     * Add a string to the transition strings map to be checked against
     * @param str the string to be added
     */
    private void addString(String str) {
        String prefix = determineLongestPrefix(str);
        String suffix = str.substring(prefix.length());

        Map<String, Object> map = getFirstMultipleTransition(
                (ImplementNode)root, prefix);
        ImplementNode multipleNode = (ImplementNode) map.get("multipleNode");
        Integer index = (Integer) map.get("charIndex");

        removeTransitionPath((index == null ? prefix : prefix.substring
                (0, index)));

        if (multipleNode != null && index != null) {
            String transitionPath = prefix.substring(0, index + 1);
            String transitionToClone = prefix.substring(index + 1);
            cloneTransitionPath(multipleNode, transitionPath,
                    transitionToClone);
        }

        addTransitionPath((ImplementNode)root.transition(prefix), suffix);
    }

    /**
     * Add a transition path to the set to be compared against
     * @param startNode the start node
     * @param str the string to be added
     */
    private void addTransitionPath(ImplementNode startNode, String str) {
        if (!str.isEmpty()) {
            ImplementNode temp = startNode;
            for (int i = 0; i < str.length(); i++, transitionCount++) {
                temp = temp.addTransition(str.charAt(i),
                        (i == str.length() - 1));

                charSet.add(str.charAt(i));
            }

        } else {
            startNode.setWord(true);
        }
    }

    /**
     * Recursively reduce the transtions
     * @param startNode teh start node
     * @param transStr the transition string
     */
    private void minimize(ImplementNode startNode, String transStr) {
        char labelChar = transStr.charAt(0);
        ImplementNode targetNode = startNode.transition(labelChar);
        if (targetNode.hasTransitions() && !transStr.substring(1).isEmpty()) {
            minimize(targetNode, transStr.substring(1));
        }

        ImplementNode equivNode = equivalenceClass.get(targetNode);

        if (equivNode == null) {
            equivalenceClass.put(targetNode, targetNode);
        } else if (equivNode != targetNode){
            targetNode.reduceTransitionCount(1);
            transitionCount -= targetNode.getIncomingTransition();
            startNode.changeTransition(labelChar, targetNode, equivNode);
        }
    }

    /**Get the position where the selected string starts
     * @param prev the previous string
     * @param curr the current string
     * @return int the position where the string starts
     */
    private int calcStartIndex(String prev, String curr) {
        int i;
        if (!curr.startsWith(prev)) {
            int min = Math.min(curr.length(), prev.length());
            for (i = 0; i < min; i++) {
                if (prev.charAt(i) != curr.charAt(i)) {
                    break;
                }
            }
        }
        else {
            return -1;
        }

        return i;
    }

    /**
     * CHeck if the provided word exists in the transition
     * @param word the word to be searched for
     * @return boolean if the word exists
     */
    @Override
    public boolean search(String word) {
        ImplementNode target = (ImplementNode)root.transition(word);
        return (target != null && target.isWord());
    }

    /**
     * Add a word read from the buffered reader into the transitions
     * @param br the input stream containing the data
     */
    @Override
    public void insert(BufferedReader br) {
        List<String> words = new ArrayList<>();
        try {
            String curr;
            while ((curr = br.readLine()) != null) {
                curr = curr.toUpperCase();
                words.add(curr);
            }
            br.close();
        } catch (IOException e) {
        }
        Collections.sort(words);
        String prev = "";
        for (String curr : words) {
            int index = calcStartIndex(prev, curr);

            if (index != -1) {
                String transSub = prev.substring(0, index);
                String suffix = prev.substring(index);
                minimize((ImplementNode)root.transition(transSub), suffix);
            }
            addString(curr);
            prev = curr;
        }
        minimize((ImplementNode)root, prev);

        root.setWord(false);
    }
}

/**
 * This class is for transitions
 */

class Transition extends Dictionary {
    private int nodeId;

    /**
     * Initialize class variables
     */
    public Transition() {
        nodeId = 0;
        root = new TransitionNode(nodeId++);
    }

    /**adds a list of words read in to the dictionary
     * @param br the buffered reader containing the information
     */
    @Override
    public void insert(BufferedReader br){
        List<String> words = new ArrayList<>();
        try {
            String word;
            while ((word = br.readLine()) != null) {
                word = word.toUpperCase();
                words.add(word);
            }
            Collections.sort(words);
            br.close();
        } catch (IOException e) {
        }
        for (String word : words) {
            insert(word);
        }
        root.setWord(false);
    }

    /**Add a single wor to the dictionary
     * @param word the word to be inserted
     */
    private void insert(String word) {
        TransitionNode temp = (TransitionNode) root;
        for (int i = 0; i < word.length(); i++) {
            if (!temp.getCharacterNodeMap().containsKey(word.charAt(i))) {
                temp.getCharacterNodeMap().put(word.charAt(i),
                        new TransitionNode(nodeId++));
            }
            temp = (TransitionNode) temp.getCharacterNodeMap().
                    get(word.charAt(i));
        }
        temp.setWord(true);
    }

    /**
     * Check if a word exists in the dictionary
     * @param word the word to be searched for
     * @return boolean to see if word is in dictionary
     */
    @Override
    public boolean search(String word) {
        TransitionNode temp = (TransitionNode)root;
        for (int i = 0; i < word.length(); i++) {
            if (!temp.getCharacterNodeMap().containsKey(word.charAt(i))) {
                return false;
            }
            temp = (TransitionNode)temp.getCharacterNodeMap().get
                    (word.charAt(i));
        }

        return (temp != null && temp.isWord());
    }

    @Override
    public String toString() {
        return root.toString();
    }
}
