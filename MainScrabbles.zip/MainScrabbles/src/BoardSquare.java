/**
 * This class manages the board's squares
 */

import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;

public class BoardSquare {
    private int wordMultiplier;
    private int letterMultiplier;
    private Tile tile;
    private boolean placed;
    private Pane pane;
    private Pane oldPane;


    public BoardSquare() {
        wordMultiplier = 1;
        letterMultiplier = 1;
        tile = null;
        pane = null;
        placed = false;
    }

    /**
     * Creates the display
     */
    private void createDisplay() {
        if (tile == null) {
            pane = new StackPane();
            Rectangle rect = new Rectangle(40, 40);
            rect.setStrokeType(StrokeType.INSIDE);
            rect.setStroke(Color.BLACK);
            if (wordMultiplier == 1 && letterMultiplier == 1) {
                rect.setFill(Color.LAWNGREEN);
            } else if (wordMultiplier > 1) {
                rect.setFill((wordMultiplier == 2) ? Color.PINK : Color.RED);
            } else if (letterMultiplier > 1) {
                rect.setFill((letterMultiplier == 2) ?
                        Color.LIGHTBLUE : Color.DARKBLUE);
            }
            pane.getChildren().add(rect);
        }
        else {
            pane = tile.getDisplay();
        }
    }

    /**
     * Gets the display pane
     * @return pane for display
     */
    public Pane getDisplay() {
        if (pane == null) {
            createDisplay();
        }
        return pane;
    }

    /**
     * Creates the board square
     * @param tile is a type of Tile
     */
    public BoardSquare(Tile tile) {
        wordMultiplier = 1;
        letterMultiplier = 1;
        this.tile = tile;
        placed = true;
    }

    /**
     * Gets the board square
     * @param multiplier is type int
     * @param word is type boolean
     */
    public BoardSquare(int multiplier, boolean word) {
        if (word) {
            wordMultiplier = multiplier;
            letterMultiplier = 1;
        } else {
            letterMultiplier = multiplier;
            wordMultiplier = 1;
        }
        tile = null;
    }

    /**
     * Gets the tile's character
     * @return char if the tile
     */
    public char getTileCharacter() {
        if (tile != null) {
            return tile.letter;
        }
        return '.';
    }

    /**
     * Place a tile on the board
     * @param t the tile to be played on the board
     */
    public void playTile(Tile t) {
        if (tile == null) {
            this.tile = t;
        } else {
            this.tile.renewDisplay(true);
        }
        this.wordMultiplier = 1;
        this.letterMultiplier = 1;
        placed = true;
        t.unHide();
        if (pane != null) {
            this.pane = t.getDisplay();
        }
    }

    /**
     * Places the tile
     * @param t is type Tile
     */
    public void placeTile(Tile t) {
        this.tile = t;
        if (pane != null) {
            this.oldPane = pane;
            this.pane = t.getDisplay();
        }
    }

    /**
     * Removes the tile from the position that was placed
     */
    public void unPlaceTile() {
        this.tile = null;
        pane = oldPane;
        oldPane = null;
    }

    /**
     * Get the multiplier for the position on the board
     * @return int for position on board
     */
    public int getWordMultiplier() {
        return wordMultiplier;
    }

    /**
     * Gets the multiplier for the letter
     * @return int for the letter multiplier
     */
    public int getLetterMultiplier() {
        return letterMultiplier;
    }

    /**
     * Gets the tile
     * @return tile
     */
    public Tile getTile() {
        return tile;
    }

    /**
     * Checks if the tile is empty
     * @return boolean for if the tile is empty
     */
    public boolean isEmpty() {
        return (tile == null || !placed);
    }

    @Override
    public String toString() {
        if (tile != null) {
            return tile.toString();
        } else {
            String str = "";
            if (wordMultiplier > 1) {
                str+=wordMultiplier;
            } else {
                str+=".";
            }

            if (letterMultiplier > 1) {
                str+=letterMultiplier;
            } else {
                str+=".";
            }

            str+=" ";
            return str;
        }
    }
}
