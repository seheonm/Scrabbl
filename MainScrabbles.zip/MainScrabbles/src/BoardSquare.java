/**
 * This class manages the board's squares
 */

import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;

public class BoardSquare {
    private int wordMultiplier;
    private int letterMultiplier;
    private Tile tile;
    private boolean placed;
    private Pane pane;
    private Pane oldPane;


    public BoardSquare() {
        wordMultiplier = 1;
        letterMultiplier = 1;
        tile = null;
        pane = null;
        placed = false;
    }

    private void createDisplay() {
        if (tile == null) {
            pane = new StackPane();
            Rectangle rect = new Rectangle(40, 40);
            rect.setStrokeType(StrokeType.INSIDE);
            rect.setStroke(Color.BLACK);
            if (wordMultiplier == 1 && letterMultiplier == 1) {
                rect.setFill(Color.LAWNGREEN);
            } else if (wordMultiplier > 1) {
                rect.setFill((wordMultiplier == 2) ? Color.PINK : Color.RED);
            } else if (letterMultiplier > 1) {
                rect.setFill((letterMultiplier == 2) ?
                        Color.LIGHTBLUE : Color.DARKBLUE);
            }
            pane.getChildren().add(rect);
        }
        else {
            pane = tile.getDisplay();
        }
    }

    public Pane getDisplay() {
        if (pane == null) {
            createDisplay();
        }
        return pane;
    }

    public BoardSquare(Tile tile) {
        wordMultiplier = 1;
        letterMultiplier = 1;
        this.tile = tile;
        placed = true;
    }

    public BoardSquare(int multiplier, boolean word) {
        if (word) {
            wordMultiplier = multiplier;
            letterMultiplier = 1;
        } else {
            letterMultiplier = multiplier;
            wordMultiplier = 1;
        }
        tile = null;
    }

    public char getTileCharacter() {
        if (tile != null) {
            return tile.letter;
        }
        return '.';
    }

    /**
     * Place a tile on the board
     * @param t the tile to be played on the board
     */
    public void playTile(Tile t) {
        if (tile == null) {
            this.tile = t;
        } else {
            this.tile.renewDisplay(true);
        }
        this.wordMultiplier = 1;
        this.letterMultiplier = 1;
        placed = true;
        t.unHide();
        if (pane != null) {
            this.pane = t.getDisplay();
        }
    }

    public void placeTile(Tile t) {
        this.tile = t;
        if (pane != null) {
            this.oldPane = pane;
            this.pane = t.getDisplay();
        }
    }

    public void unPlaceTile() {
        this.tile = null;
        pane = oldPane;
        oldPane = null;
    }

    /**
     * Get the multiplier for the position on the board
     * @return int for position on board
     */
    public int getWordMultiplier() {
        return wordMultiplier;
    }

    public int getLetterMultiplier() {
        return letterMultiplier;
    }

    public Tile getTile() {
        return tile;
    }

    public boolean isEmpty() {
        return (tile == null || !placed);
    }

    @Override
    public String toString() {
        if (tile != null) {
            return tile.toString();
        } else {
            String str = "";
            if (wordMultiplier > 1) {
                str+=wordMultiplier;
            } else {
                str+=".";
            }

            if (letterMultiplier > 1) {
                str+=letterMultiplier;
            } else {
                str+=".";
            }

            str+=" ";
            return str;
        }
    }
}
