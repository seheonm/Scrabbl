/**
 * This class generates the tiles
 */

import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;

import java.util.function.BiConsumer;
import java.util.function.Consumer;


public class Tile {
    char letter;
    int value;
    private boolean hidden;

    private Pane disp;

    public Tile(char letter, int value) {
        this.letter = letter;
        this.value = value;
        disp = null;
    }

    /**
     * Generate display for the tile
     */
    private void createDisplay() {
        disp = new Pane();
        Rectangle rect = new Rectangle(40, 40);
        rect.setStroke(Color.BLACK);
        rect.setStrokeType(StrokeType.INSIDE);
        rect.setFill(Color.BROWN);
        disp.getChildren().add(rect);
        Text text = new Text(9, 30, letter + "");
        text.setFont(new Font(25));
        text.setTextAlignment(TextAlignment.CENTER);
        disp.getChildren().add(text);
        text = new Text(28, 35, Integer.toString(value));
        text.setFont(new Font(10));
        text.setTextAlignment(TextAlignment.CENTER);
        disp.getChildren().add(text);
    }

    /**
     * Sets the letters
     * @param c of type char
     */
    public void setLetter(char c) {
        this.letter = c;
    }

    /**
     * Changes the blank test
     * @param c of type char
     */
    public void changeBlankText(char c) {
        Text text = new Text(15, 32, c + "");
        text.setFont(new Font(25));
        text.setTextAlignment(TextAlignment.CENTER);
        disp.getChildren().set(1, text);
    }

    /**
     * Add the tile to the tray of a player and attach necessary event handlers
     * @param hand the display item containing the tile
     * @param board the board object
     * @param droppedCallBack event called when a drop is invalid
     * @param returnedCallback event called when a tile is returned
     */
    public void setTiles(HBox hand, GridPane board, BiConsumer<Tile,
            Position> droppedCallBack, Consumer<Tile> returnedCallback) {
        if (disp == null) {
            createDisplay();
        }

        disp.setOnDragDetected(mouseEvent -> {
            if (mouseEvent.isPrimaryButtonDown()) {
                disp.startFullDrag();
                disp.setViewOrder(-2);
            }
            mouseEvent.consume();
        });

        disp.setOnMousePressed(mouseEvent -> {
            if (mouseEvent.isSecondaryButtonDown()) {
                double sceneY = mouseEvent.getSceneY() - 40;
                double sceneX = mouseEvent.getSceneX() - 25;
                //Get the position with respect to the board
                Position pos =
                        new Position(
                                (int)Math.floor(sceneY / 40),
                                (int)Math.round(sceneX / 40));
                UpdateTiles drop = new UpdateTiles(pos, this, true);
                //Fire a drop event, that is really a reset
                board.fireEvent(drop);
                if (!hand.getChildren().contains(disp)) {
                    hand.getChildren().add(disp);
                }
                //Call returned callback
                returnedCallback.accept(this);
                disp.setTranslateY(0);
                disp.setTranslateX(0);
                disp.setViewOrder(0);
            }
            mouseEvent.consume();
        });

        disp.setOnMouseDragged(mouseEvent -> {
            if (mouseEvent.isPrimaryButtonDown()) {
                disp.setTranslateX(mouseEvent.getX() +disp.getTranslateX()-25);
                disp.setTranslateY(mouseEvent.getY() +disp.getTranslateY()-25);
            }
            mouseEvent.consume();
        });

        //When they let go of the drag
        disp.setOnMouseDragReleased(mouseDragEvent -> {
            double sceneY = mouseDragEvent.getSceneY() - 40;
            double sceneX = mouseDragEvent.getSceneX() - 25;
            //Get position with respect to board
            Position pos =
                    new Position(
                            (int)Math.floor(sceneY / 40),
                            (int)Math.round(sceneX / 40));
            UpdateTiles drop = new UpdateTiles(pos, this, false);
            //Fire dropevent to board
            board.fireEvent(drop);
            disp.setTranslateY(0);
            disp.setTranslateX(0);
            disp.setViewOrder(0);
            //Call dropped if the letter is now on the board
            if (!disp.getParent().equals(hand)) {
                droppedCallBack.accept(this, pos);
            }
            mouseDragEvent.consume();
        });

    }

    /**
     * Gets the display
     * @return display
     */
    public Pane getDisplay() {
        if (disp == null) {
            createDisplay();
        }
        return disp;
    }

    /**
     * Renews the display
     * @param newDisplay of type boolean for if there is a new display
     */
    public void renewDisplay(boolean newDisplay) {
        if (newDisplay || disp == null) {
            createDisplay();
        }
    }

    /**
     * Hides the display
     */
    public void hide() {
        try{
            if (disp == null) {
                    createDisplay();

            }
            if (!hidden) {
                hidden = true;
                disp.getChildren().remove(1, 3);
            }
        }catch(Exception e){}
    }

    /**
     * Unhides the display
     */
    public void unHide() {
        if (hidden) {
            hidden = false;
            createDisplay();
        }
    }

    /**
     * Checks if there is a blank
     * @return boolean if there is a blank
     */
    public boolean isBlank() {
        return (letter == '*' || value == 0);
    }

    @Override
    public String toString() {
        String  str = " ";
        if (value == 0) {
            str+=letter;
        } else {
            str+=letter;
            str = str.toUpperCase();
        }
        str+= " ";
        return str;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (!(obj instanceof Tile)) return false;
        Tile other = (Tile)obj;

        return (this.letter == other.letter
                && this.letter == other.letter
                && this.value == other.value);
    }
}
