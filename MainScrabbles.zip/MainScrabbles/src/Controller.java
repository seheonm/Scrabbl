/**
 * This class manages controls
 */

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Controller {

    private @FXML HBox computerHand;
    private @FXML GridPane board;
    private @FXML HBox playerHand;
    private @FXML VBox rightSide;
    private @FXML Button playMove;
    private @FXML Label computerScore;
    private @FXML Label playerScore;

    /**
     * Gets the computer's hand
     * @return computer's hand
     */
    public HBox getComputerHand() {
        return computerHand;
    }

    /**
     * Gets the board
     * @return board
     */
    public GridPane getBoard() {
        return board;
    }

    /**
     * Gets the player's hand
     * @return player's hand
     */
    public HBox getPlayerHand() {
        return playerHand;
    }

    /**
     * Initializes the board
     */
    public void initialize() {
        board.setBackground( new Background( new BackgroundFill
                (Color.WHITE, CornerRadii.EMPTY,Insets.EMPTY)));
        computerHand.setBackground(new Background(new BackgroundFill
                (Color.LIGHTSLATEGRAY, CornerRadii.EMPTY,Insets.EMPTY)));
        playerHand.setBackground(new Background(new BackgroundFill
                (Color.LIGHTSLATEGRAY,CornerRadii.EMPTY,Insets.EMPTY)));
        computerScore.setText("0");
        playerScore.setText("0");
        computerScore.setFont(new Font(40));
        playerScore.setFont(new Font(40));
    }

    /**
     * Initialize player displays
     * @param user  the player object with the player information
     * @param dict dictionary containing all valid words
     */
    public void setupForUserPlayer(HumanPlayer user, Dictionary dict) {
        playMove.setOnMouseClicked(mouseEvent -> user.attemptPlayMove
                (mouseEvent, dict));
        rightSide.setOnMouseDragReleased(user::exchangeTile);
        playerHand.setOnMouseDragReleased(user::resetTile);
    }

    /**
     * Updates the score for the player
     * @param score of type int for the score
     * @param player of type Player for the player
     */
    public void updateScore(int score, Player player) {
        if (player instanceof ComputerPlayer) { computerScore.setText
                (Integer.toString(Integer.parseInt
                        (computerScore.getText()) + score));
        } else if (player instanceof HumanPlayer) {
            playerScore.setText(Integer.toString
                    (Integer.parseInt(playerScore.getText()) + score));
        }
    }

    /**
     * Find the top score
     * @return top score
     */
    public int getTopScore() {
        return Integer.parseInt(computerScore.getText());
    }

    /**
     * Gets the lowest score
     * @return low score
     */
    public int getBottomScore() {
        return Integer.parseInt(playerScore.getText());
    }

}




