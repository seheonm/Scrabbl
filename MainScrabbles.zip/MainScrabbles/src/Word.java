/**
 * This class manages the words made
 */

import java.util.HashMap;
import java.util.Map;

/**
 * Represents a single word in the dictionary
 */
abstract public class Word {
    protected Map<Character, Word> characterNodeMap;
    protected boolean isWord;

    public Word() {
        characterNodeMap = new HashMap<>();
        isWord = false;
    }

    /**
     * Transition this word along an edge
     * @param c the transitions valid for that letter
     * @return word that transitions
     */
    abstract public Word transition(char c);

    /**
     * Transition this node along the characters in the string
     * @param trans the transitions valid for that string
     * @return the characters
     */
    abstract public Word transition(String trans);

    /**
     * Get the transition mappings
     * @return mapping
     */
    public Map<Character, Word> getCharacterNodeMap() {
        return characterNodeMap;
    }

    public void setWord(boolean word) {
        isWord = word;
    }

    public boolean isWord() {
        return isWord;
    }
}

/**
 * This class is for the transition node
 */
class TransitionNode extends Word {
    private int nodeId;

    /**
     * Basic constructor for trie node
     * takes a unique nodeId
     * @param nodeId the id to represent this node
     */
    public TransitionNode(int nodeId) {
        super();
        this.nodeId = nodeId;
    }

    /**
     * Transition this node along an edge
     * represented by c
     * @param c the character representing the transition
     * @return the node that is reached by the transition
     */
    @Override
    public TransitionNode transition(char c) {
        return (TransitionNode)characterNodeMap.get(c);
    }

    /**
     * Transition this node along a list of edges
     * @param trans the string of chars representing the transition
     * @return the node reached by transitioning along trans
     */
    @Override
    public TransitionNode transition(String trans) {
        TransitionNode temp = this;
        int length = trans.length();
        for (int i = 0; i < length; i++) {
            temp = temp.transition(trans.charAt(i));
            if (temp == null) break;
        }
        return temp;
    }

    /**
     * The hash code for this is the unique id
     * @return the unique node id
     */
    @Override
    public int hashCode() {
        return nodeId;
    }

    /**
     * To String for printing out the trie
     * @return the string representation of this node
     */
    @Override
    public String toString() {
        return ((isWord) ? "*" : "") + characterNodeMap.toString();
    }
}

/**
 * This class is for implementing words
 */
class ImplementNode extends Word {
    private int incomingTransition;
    private Integer hashCode;

    /**
     * Implement this node as a word
     * @param isWord boolean to determine whether it's a word or not
     */
    public ImplementNode(boolean isWord) {
        super();
        hashCode = null;
        this.isWord = isWord;
    }

    /**
     * Initialize this node from another node
     * @param node the node used to initialize this object
     */
    public ImplementNode(ImplementNode node) {
        super();
        this.isWord = node.isWord;
        characterNodeMap = new HashMap<>(node.characterNodeMap);
        hashCode = null;
        for (Word value : characterNodeMap.values()) {
            ImplementNode v = (ImplementNode) value;
            v.incomingTransition++;
        }
    }

    public int getIncomingTransition() {
        return incomingTransition;
    }

    public boolean hasTransition(char letter) {
        return characterNodeMap.containsKey(letter);
    }

    @Override
    public ImplementNode transition(char letter) {
        return (ImplementNode)characterNodeMap.get(letter);
    }

    @Override
    public ImplementNode transition(String transStr) {
        ImplementNode temp = this;
        for (int i = 0; i < transStr.length(); i++) {
            temp = temp.transition(transStr.charAt(i));
            if (temp == null) break;
        }

        return temp;
    }

    /**
     * Make a copy of the current node
     * @return new ImplementNode
     */
    public ImplementNode clone() {
        return new ImplementNode(this);
    }

    /**
     * Make a copy from the parent and character label
     * @param parent the parent node of the object
     * @param transLabel the character text
     * @return ImplementNode
     */
    public ImplementNode clone(ImplementNode parent, char transLabel) {
        ImplementNode clone = new ImplementNode(this);
        parent.changeTransition(transLabel, this, clone);

        return clone;
    }

    /**
     * Set the node to have a new transtion
     * @param letter the letter to be changed
     * @param oldNode the node that used to contain it
     * @param newNode the node that will now hold it
     */
    public void changeTransition(char letter, ImplementNode oldNode,
                                 ImplementNode newNode) {
        oldNode.incomingTransition--;
        newNode.incomingTransition++;

        characterNodeMap.put(letter, newNode);
    }

    /**
     * Add a transition to this implementation
     * @param letter the to be added
     * @param isWord deteremine if it's part of a word or not
     * @return ImplementNode
     */
    public ImplementNode addTransition(char letter, boolean isWord) {
        ImplementNode newNode = new ImplementNode(isWord);
        newNode.incomingTransition++;

        characterNodeMap.put(letter, newNode);

        return newNode;
    }

    public void clearHash() {
        hashCode = null;
    }

    /**Check if there are any transitions for this implementation
     * @return boolean for transitions
     */
    public boolean hasTransitions() {
        return !characterNodeMap.isEmpty();
    }

    /**
     * Get the number of transitions for this implementation
     * @return int for transitions
     */
    public int getTransitionCount() {
        return characterNodeMap.size();
    }

    public void reduceTransitionCount(int toReduce) {
        incomingTransition -= toReduce;
    }

    public boolean hasMultipleIncomingTrans() {
        return incomingTransition >= 2;
    }

    public static boolean compareTransitions
            (ImplementNode node1, ImplementNode node2) {
        Map<Character, Word> map1 = node1.characterNodeMap;
        Map<Character, Word> map2 = node2.characterNodeMap;

        if (map1.size() == map2.size()) {
            for (Map.Entry<Character, Word> keyValue : map1.entrySet()) {
                char current = keyValue.getKey();
                ImplementNode currentNode = (ImplementNode)keyValue.getValue();

                if (!map2.containsKey(current) ||
                        !map2.get(current).equals(currentNode)) {
                    return false;
                }
            }
        }
        else {
            return false;
        }

        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;

        if (!(obj instanceof ImplementNode)) {
            return false;
        }

        ImplementNode that = (ImplementNode)obj;
        return (isWord == that.isWord && compareTransitions(this, that));
    }

    @Override
    public int hashCode() {
        if (hashCode == null) {
            int hash = 11;
            hash = 37 * hash + (this.isWord ? 1 : 0);
            hash = 37 * hash + (this.characterNodeMap != null ?
                    characterNodeMap.hashCode() : 0);
            hashCode = hash;
            return hash;
        }
        else {
            return hashCode;
        }
    }
}
