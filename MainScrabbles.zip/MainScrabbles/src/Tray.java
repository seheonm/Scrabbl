/**
 * This class organizes the tray
 */

import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;


public class Tray {
    List<Tile> tiles;
    boolean tilesSet;

    public Tray() {
        tiles = new ArrayList<>();
        tilesSet = false;
    }

    /**
     * Get the display format for the tiles in the tray
     * @return displays for tiles
     */
    public List<Pane> getTileDisplays() {
        List<Pane> displays = new ArrayList<>();
        for (Tile letter : tiles) {
            displays.add(letter.getDisplay());
        }
        return displays;
    }

    /**
     * Set the tiles to the ones drawn
     * @param tiles the tiles to be copied
     */
    public void setTiles(List<Tile> tiles) {
        this.tiles = tiles;
    }

    public List<Tile> getTiles() {
        return tiles;
    }

    /**
     * CHeck if a character is in the tray
     * @param c the letter to be checked
     * @return boolean if character is in tray
     */
    public boolean isInTray(char c) {
        for (Tile t : tiles) {
            if (t.letter == c || t.isBlank()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Make tray characters hidden
     */
    public void hideTray() {
        for (Tile t : tiles) {
            t.hide();
        }
    }

    public int size() {
        return tiles.size();
    }

    /**
     * Draw tiles from the tile manager to fill the tray
     * @param manager the class with all the extra tiles
     */
    public void fillTray(TilesManager manager) {
        int size = tiles.size();
        for (int i = size; i < 7; i++) {
            Tile toAdd = manager.drawOne();
            if (toAdd == null) {
                break;
            }
            tiles.add(toAdd);
        }
    }

    /**Remove the selected tiles from the tray
     * @param toRemove the tiles to be removed from the tray
     */
    public void removeTiles(List<Tile> toRemove) {
        tiles.removeAll(toRemove);
    }

    /**
     * Remove a single tile from the tray
     * @param c the tile to be removed from the tray
     * @return Tile from tray
     */
    public Tile removeTile(char c) {
        Tile toRemove = null;
        for (Tile t : tiles) {
            if (t.letter == c || t.isBlank()) {
                toRemove = t;
                break;
            }
        }
        tiles.remove(toRemove);
        return toRemove;
    }

    /**
     * Replace the given tile with a new one from the tile manager
     * @param manager teh class that handles the extra tiles
     * @param t
     */
    public void replace(TilesManager manager, Tile t) {
        tiles.remove(t);
        manager.putBack(t);
        tiles.add(manager.drawOne());
    }

    /**Add tile to the tray
     * @param t the tile to be added to the tray
     */
    public void addTile(Tile t) {
        tiles.add(t);
    }

    /**
     * Add all the tiles to the hand display of the player
     * @param hand the display object that shows all the players tiles
     * @param board the board object
     * @param droppedCallback the event called when an invalid drop is made
     * @param returnedCallback the event called when a tile si returned
     */
    public void setTiles(HBox hand, GridPane board, BiConsumer<Tile,
            Position> droppedCallback, Consumer<Tile> returnedCallback) {
        tilesSet = true;
        for (Tile t : tiles) {
            t.setTiles(hand, board, droppedCallback, returnedCallback);
        }
    }

    /**
     * Check if the tray contains a tile
     * @param pane check if the letter in the pane is contained in the tray
     * @return boolean for if tile is in tray
     */
    public boolean contains(Pane pane) {
        for (Tile t : tiles) {
            if (t.getDisplay() == pane) {
                return true;
            }
        }
        return false;
    }

    /**
     * Get the tile in the provided pane
     * @param pane the pane containing the letter
     * @return Tile in pane
     */
    public Tile getTile(Pane pane) {
        for (Tile t : tiles) {
            if (t.getDisplay() == pane) {
                return t;
            }
        }
        return null;
    }

    /**
     * Get total score of all words in the tile
     * @return int score of words in tile
     */
    public int getTrayTotal() {
        int sum = 0;
        for (Tile t : tiles) {
            sum += t.value;
        }
        return sum;
    }

    public boolean hasTiles() {
        return tilesSet;
    }

    public boolean isEmpty() {
        return tiles.isEmpty();
    }

    @Override
    public String toString() {
        return tiles.toString();
    }

}
