/**
 * This class manages the board operations
 */

import javafx.scene.control.ChoiceDialog;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

public class Board {
    //Declare class variables
    private int size;
    private BoardSquare[][] tiles;
    private boolean isEmpty;
    private boolean isTransposed;
    private TilesManager tileManager;
    private Map<Position, Integer> crossSum;
    private Set<Position> potentialAnchors;
    private Map<Tile, Position> overridden;
    private boolean initGui;
    private GridPane board;


    /**
     * Constructor to initialize variables
     */
    public Board() {
        size = 0;
        tiles = null;
        isEmpty = true;
        tileManager = null;
        crossSum = new HashMap<>();
        isTransposed = false;
        initGui = false;
    }

    /**
     * Constructor to take in the board pane and initialize variables
     * @param board the display panel to hold the board tiles
     */
    public Board(GridPane board) {
        this();
        this.board = board;
        isTransposed = false;
        initGui = true;
        overridden = new HashMap<>();
    }

    /**
     * Read in the initial data from the input file and add the tiles to the
     * tile manager
     * @param br the stream reader that has all the data required to initialize
     *          the class
     * @param tileManager the class that handles the extra tiles
     * @return boolean to read the data or not
     */
    public boolean initialize(BufferedReader br, TilesManager tileManager) {
        this.tileManager = tileManager;
        isEmpty = true;
        overridden.clear();
        try {
            String line;
            line = br.readLine();
            if (line != null) {
                size = Integer.parseInt(line);
                tiles = new BoardSquare[size][size];
            } else {
                System.out.println("Need a size of the board");
                return false;
            }
            for (int i = 0; i < size; i++) {
                line = br.readLine();
                if (!parseLine(line, i)) {
                    return false;
                }
            }
        } catch (IOException e) {
            System.out.println("Could not open the board file");
            return false;
        }
        if (initGui) {
            initializeDisplay();
        }

        return true;
    }

    /**
     * Read in a single line and parse into characters and their values
     * @param line a single line read from input
     * @param i the row to which the data should be stored
     * @return boolean to read the line or not
     */
    private boolean parseLine(String line, int i) {
        if (line == null) {
            System.out.println("File format is incorrect");
            return false;
        }
        String[] values = line.split(" ");
        int j = 0;
        for (String s : values) {
            if (s.length() == 2) {
                if (s.charAt(0) != '.' && s.charAt(0) != '1') {
                    tiles[i][j] = new BoardSquare(
                            Integer.parseInt(s.substring(0, 1)), true);
                } else if (s.charAt(1) != '.' && s.charAt(1) != '1') {

                    tiles[i][j] = new BoardSquare(
                            Integer.parseInt(s.substring(1, 2)), false);
                } else if ((s.charAt(1) == '.' && s.charAt(0) == '.')
                        || (s.charAt(0) == '1' && s.charAt(1) == '1')) {
                    tiles[i][j] = new BoardSquare();
                }
                j++;
            } else if (s.length() == 1) {
                int score;
                if (Character.isUpperCase(s.charAt(0))) {
                    score = 0;
                } else {
                    score = tileManager.getTileValue
                            (Character.toUpperCase(s.charAt(0)));
                }
                s = s.toUpperCase();
                isEmpty = false;
                tiles[i][j] = new BoardSquare(new Tile(s.charAt(0),
                        score));
                j++;
            }
        }
        return true;
    }

    /**
     * Initialize the tiles using input provided from standard input
     * @param in the Scanner that contains the input data
     * @param manager the class that holds and handles extra tiles
     * @return boolean to initialize or not
     */
    public boolean initialize(Scanner in, TilesManager manager) {
        this.tileManager = manager;
        size = in.nextInt();
        in.nextLine();
        tiles = new BoardSquare[size][size];
        String line;

        for (int i = 0; i < size; i++) {
            line = in.nextLine();
            if (!parseLine(line, i)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Create the initial board with empty tiles
     */
    private void initializeDisplay() {
        board.getChildren().clear();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Pane p = tiles[i][j].getDisplay();
                GridPane.setRowIndex(p, i);
                GridPane.setColumnIndex(p, j);
                board.getChildren().add(p);
            }
        }
        board.addEventHandler(UpdateTiles.UPDATE_TILES, this::dropHandler);
    }

    /**
     * @return the size of the board
     */
    public int getSize() {

        return size;
    }

    /**check if a cell is empty
     * @param row the row index
     * @param col the column index
     * @return boolean for if the cell is empty or not
     */
    public boolean isEmpty(int row, int col) {

        return tiles[row][col].isEmpty();
    }

    /**
     * Get the tile at a certain position
     * @param row the row index
     * @param col the column index
     * @return Tile for position
     */
    public Tile getTile(int row, int col) {

        return tiles[row][col].getTile();
    }

    /**
     * Add a word to the board and check if it is valid
     * @param word the word that is to be played
     * @param letters the tiles that make up that word
     * @param start the start location of the word
     * @param end the end position of the word
     * @return boolean to add a word or not
     */
    public boolean playWord(String word, List<Tile> letters, Position start,
                            Position end) {
        boolean across = (start.getRow() == end.getRow());
        int j;
        Position current = new Position(start);

        for (int i = 0; i < word.length(); i++) {
            Tile toPlay = null;
            if (this.tiles[current.getRow()][current.getCol()].isEmpty()) {
                for (j = 0; j < letters.size(); j++) {
                    if(letters.get(j).letter == word.charAt(i)) {
                        toPlay = letters.get(j);
                        break;
                    }
                }
                if (j < letters.size() && toPlay != null) {
                    letters.remove(j);
                }
                if (toPlay == null) {
                    for (j = 0; j < letters.size(); j++) {
                        if(letters.get(j).letter == word.charAt(i)
                                || letters.get(j).isBlank()) {
                            toPlay = letters.get(j);
                            if (initGui) {
                                toPlay.unHide();
                                toPlay.changeBlankText(word.charAt(i));
                            }
                            if (toPlay.isBlank()) {
                                toPlay.setLetter(word.charAt(i));
                            }
                            break;
                        }
                    }
                    if (j < letters.size()) {
                        letters.remove(j);
                    }
                }
                int row = current.getRow();
                int col = current.getCol();
                this.tiles[row][col].playTile(toPlay);
                if (initGui) {
                    Pane p = this.tiles[row][col].getDisplay();
                    GridPane.setColumnIndex(p, col);
                    GridPane.setRowIndex(p, row);
                    if (!board.getChildren().contains(p)) {
                        board.getChildren().set(row * size + col, p);
                    }
                }
                if (across) {
                    current.incrementCol();
                } else {
                    current.incrementRow();
                }
            } else {
                if (across) {
                    current.incrementCol();
                }
                else {
                    current.incrementRow();
                }
            }
        }
        isEmpty = false;

        if (initGui) {
            overridden.clear();
        }
        return true;
    }

    /**Gat all positions that could be used to connect to the current board
     * @return position information
     */
    public Set<Position> getPotentialAnchorSquares() {
        potentialAnchors = new HashSet<>();
        if (isEmpty) {
            potentialAnchors.add(new Position(size / 2, size / 2));
            return potentialAnchors;
        }
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (anyAdjacentFilled(i, j)) {
                    potentialAnchors.add(new Position(i, j));
                }
            }
        }
        return potentialAnchors;
    }

    /**
     * CHeck if the provided position is next to an occupied square
     * @param row the row index
     * @param col the column index
     * @return boolean if the position is occupied or not
     */
    private boolean anyAdjacentFilled(int row, int col) {
        if (!tiles[row][col].isEmpty()) {
            return false;
        }
        if (row > 0) {
            if (!tiles[row - 1][col].isEmpty()) {
                return true;
            }
        }
        if (row < size - 1) {
            if (!tiles[row + 1][col].isEmpty()) {
                return true;
            }
        }
        if (col > 0) {
            if (!tiles[row][col - 1].isEmpty()) {
                return true;
            }
        }
        if (col < size - 1) {
            if (!tiles[row][col + 1].isEmpty()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Add the set of characters to a map that corresponds to their score if
     * they are played
     * @param crossCheck the map that contains the words made and their value
     * @param row the row index
     * @param col the column index
     * @param dict the dictionary object to confirm the word is valid
     * @param prefix the letters that are added on the left or top of an anchor
     *              tile
     * @return int for the corresponding spots
     */
    private int addToCrossCheck(Map<Integer, Set<Character>> crossCheck,
                                int row,
                                int col,
                                Dictionary dict,
                                boolean prefix) {
        String string = (prefix ? buildPrefixString(row, col)
                : buildSuffixString(row, col));
        StringBuilder actual = new StringBuilder();
        if (string.contains("*")) {
            if (prefix) {
                for (int i = 0; i < string.length(); i++) {
                    if (string.charAt(i) == '*') {
                        actual.append(tiles[row - (i + 1)][col]
                                .getTileCharacter());
                    } else {
                        actual.append(string.charAt(i));
                    }
                }
            } else {
                for (int i = 0; i < string.length(); i++) {
                    if (string.charAt(i) == '*') {
                        actual.append(tiles[row + (i + 1)][col]
                                .getTileCharacter());
                    } else {
                        actual.append(string.charAt(i));
                    }
                }
            }
        } else {
            actual = new StringBuilder(string);
        }

        Set<Character> c = new HashSet<>();
        for (char alphabet = 'A'; alphabet <= 'Z'; alphabet++) {
            if (prefix) {
                if (dict.search(actual.toString() + alphabet)) {
                    c.add(alphabet);
                }
            } else {
                if (dict.search(alphabet + actual.toString())) {
                    c.add(alphabet);
                }
            }
        }
        crossCheck.put(row * size + col, c);
        return tileManager.getValue(string);
    }

    /**
     * Search the words in the dictionary for words that can be played
     * as valid moves and add them to the map with their score
     * @param dict the dictionary to provide a list of valid words to be played
     * @return map checker
     */
    public Map<Integer, Set<Character>> generateCrossChecks(Dictionary dict) {
        this.crossSum.clear();
        Map<Integer, Set<Character>> crossCheckMap = new HashMap<>();
        if (isEmpty) {
            return crossCheckMap;
        }
        int crossSum;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                crossSum = checkTiles(dict, crossCheckMap, i, j);
                if (crossSum != -1) {
                    this.crossSum.put(new Position(i, j), crossSum);
                }
            }
        }

        return crossCheckMap;
    }

    /**
     * Check if the word found can be validly placed on the board and
     * calculate it's score
     * @param dict the dictionary to provide a list of valid words
     * @param crossCheckMap the map containing the set of words to be checked
     *                     against
     * @param row the row index
     * @param col the column index
     * @return int to check the tiles
     */
    private int checkTiles(Dictionary dict,
                           Map<Integer, Set<Character>> crossCheckMap,
                           int row,
                           int col) {
        if (isBelow(row, col) && isAbove(row, col) && isEmpty(row, col)) {
            String prefix = buildPrefixString(row, col);
            String suffix = buildSuffixString(row, col);
            Set<Character> c = new HashSet<>();
            for (char alphabet = 'A'; alphabet <= 'Z'; alphabet++) {
                if (dict.search(prefix + alphabet + suffix)) {
                    c.add(alphabet);
                }
            }
            crossCheckMap.put(row * size + col, c);
            int prefixValue = tileManager.getValue(prefix);
            return prefixValue + tileManager.getValue(suffix);
        }
        else if (isBelow(row, col) && isEmpty(row, col)) {
            return addToCrossCheck(crossCheckMap, row, col, dict, true);
        }
        else if (isAbove(row, col) && isEmpty(row, col)) {
            return addToCrossCheck(crossCheckMap, row, col, dict, false);
        }
        return -1;
    }

    /**
     * Get the score of the move that is to be made
     * @param word the word whose value is to be computed
     * @param move the tiles that have been played
     * @param start the start position
     * @return int to get the score
     */
    public int getValue(String word, List<Tile> move, Position start) {
        List<Tile> moveCopy = new ArrayList<>(move);
        int sum = 0;
        int crossSum = 0;
        int currentCrossSum = 0;
        int j;
        int wordMultiplier = 1;
        Position current = new Position(start);
        for (int i = 0; i < word.length(); i++) {
            Tile currentLetter = null;
            if (tiles[current.getRow()][current.getCol()].isEmpty()) {
                for (j = 0; j < moveCopy.size(); j++) {
                    if (moveCopy.get(j).letter == word.charAt(i)) {
                        currentLetter = moveCopy.get(j);
                        break;
                    }
                }
                if (j < moveCopy.size()) {
                    moveCopy.remove(j);
                }
                if (currentLetter == null) {
                    for (j = 0; j < moveCopy.size(); j++) {
                        if (moveCopy.get(j).isBlank()) {
                            currentLetter = moveCopy.get(j);
                            break;
                        }
                    }
                    if (j < moveCopy.size()) {
                        moveCopy.remove(j);
                    }
                }
                int letterMult = tiles[current.getRow()][current.getCol()]
                        .getLetterMultiplier();
                int wordMult = tiles[current.getRow()][current.getCol()]
                        .getWordMultiplier();
                currentCrossSum = getScoreFromPos(current);
                if (currentCrossSum != 0) {
                    currentCrossSum += currentLetter.value
                            * letterMult;
                }
                wordMultiplier *= wordMult;
                sum += currentLetter.value * letterMult;
                if (potentialAnchors.contains(current) && wordMult > 1) {
                    sum += currentCrossSum;
                } else {
                    crossSum += currentCrossSum;
                }
                current = new Position(current.getRow(), current.getCol() + 1);
            } else {
                sum += tiles[current.getRow()][current.getCol()]
                        .getTile().value;
                current = new Position(current.getRow(), current.getCol() + 1);
            }
        }

        sum *= wordMultiplier;
        if (move.size() == 7) {
            sum += 50;
        }
        sum += crossSum;
        return sum;
    }

    /**
     * Build a word that joins the board at it's end
     * @param startingRow the index of starting row
     * @param col the column index
     * @return String to build a word
     */
    private String buildPrefixString(int startingRow, int col) {
        int row = startingRow - 1;
        StringBuilder sb = new StringBuilder();
        while (row >= 0 && !tiles[row][col].isEmpty()) {
            if (tiles[row][col].getTile().isBlank()) {
                sb.insert(0, '*');
            } else {
                sb.insert(0, tiles[row][col].getTileCharacter());
            }
            row--;
        }
        return sb.toString();
    }

    /**
     * Build and place a word that starts with a character already on the board
     * @param startingRow the index of starting row
     * @param col the column index
     * @return String to place the word
     */
    private String buildSuffixString(int startingRow, int col) {
        int row = startingRow + 1;
        StringBuilder sb = new StringBuilder();
        while (row <= size - 1 && !tiles[row][col].isEmpty()) {
            if (tiles[row][col].getTile().isBlank()) {
                sb.append('*');
            } else {
                sb.append(tiles[row][col].getTileCharacter());
            }
            row++;
        }
        return sb.toString();
    }

    /**
     * Return the row below the given cell if it is empty
     * @param row the row index
     * @param col the column index
     * @return boolean to check the row below
     */
    private boolean isBelow(int row, int col) {
        if (row > 0 && tiles[row][col].isEmpty()) {
            return !tiles[row - 1][col].isEmpty();
        }

        return false;
    }

    /**
     * Check if the cell above the given one is eompty
     * @param row the row index
     * @param col the column index
     * @return boolean to check the row above
     */
    private boolean isAbove(int row, int col) {
        if (row < size - 1 && tiles[row][col].isEmpty()) {
            return !tiles[row + 1][col].isEmpty();
        }

        return false;
    }

    /**
     * Rotate the pieces on the board
     */
    public void transpose() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < i; j++) {
                BoardSquare temp = tiles[i][j];
                tiles[i][j] = tiles[j][i];
                tiles[j][i] = temp;
            }
        }

        isTransposed = !isTransposed;
    }

    /**Check if the board has been rotated
     * @return boolean to check if rotated
     */
    public boolean isTransposed() {
        return isTransposed;
    }

    /**
     * Retrieve the score from the given position on the board
     * @param pos the position on the board
     * @return int score from the board
     */
    private int getScoreFromPos(Position pos) {
        return crossSum.getOrDefault(pos, 0);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                sb.append(tiles[i][j].toString());
            }
            if (i != size - 1) {
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Reset all the characters on the board and return the tiles to the tile
     * manager
     */
    public void resetPlaced() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Position pos = new Position(i, j);

                if (overridden.containsValue(pos)) {
                    Tile t = tiles[i][j].getTile();

                    tiles[i][j].unPlaceTile();

                    Pane p = this.tiles[i][j].getDisplay();
                    GridPane.setColumnIndex(p, pos.getCol());
                    GridPane.setRowIndex(p, pos.getRow());
                    board.getChildren().set(i * size + j, p);

                    if (t != null && t.isBlank()) {
                        t.setLetter('*');
                        t.changeBlankText('*');
                    }
                }
            }
        }
    }

    /**
     * Handles the event when a tile is dropped onto the board
     * @param changesLetters the class that defines the drop event
     */
    private void dropHandler(UpdateTiles changesLetters) {
        Position pos = changesLetters.pos;
        Tile t = changesLetters.tile;

        if (overridden.containsValue(pos)
                && !changesLetters.reset) {
            return;
        }

        if (pos != null && (pos.getCol() < 0
                || pos.getRow() > size - 1
                || pos.getRow() < 0
                || pos.getCol() > size - 1)) {
            return;
        }

        if (overridden.containsKey(t)) {
            if (pos == null) {
                pos = overridden.get(t);
            }
            Position oldPos = overridden.get(t);
            tiles[oldPos.getRow()][oldPos.getCol()].unPlaceTile();
            Pane p = tiles[oldPos.getRow()][oldPos.getCol()].getDisplay();
            GridPane.setColumnIndex(p, oldPos.getCol());
            GridPane.setRowIndex(p, oldPos.getRow());
            try {
                board.getChildren().set(oldPos.getRow() * size + oldPos.getCol(), p);
            }catch(Exception e){}
            if (!isEmpty(pos.getRow(), pos.getCol())) {
                ((HBox) board.getParent().getChildrenUnmodifiable().get(2))
                        .getChildren().add(t.getDisplay());
            }
            overridden.remove(t);
            if (pos.equals(oldPos)) {
                if (t.isBlank()) {
                    t.setLetter('*');
                    t.changeBlankText('*');
                }
                return;
            }
        }
        if (pos != null && isEmpty(pos.getRow(), pos.getCol())
                && t != null) {
            if (t.isBlank()) {
                Set<Character> alphabet = new HashSet<>();
                for (char start = 'A'; start <= 'Z'; start++) {
                    alphabet.add(start);
                }
                ChoiceDialog<Character> dialog =
                        new ChoiceDialog<>('A', alphabet);
                dialog.setTitle("Blank Letter Choice");
                dialog.setHeaderText("Blank Letter Choice");
                dialog.setContentText("Choose your letter: ");
                Optional<Character> result = dialog.showAndWait();

                result.ifPresent(letter -> {
                    t.setLetter(letter);
                    t.changeBlankText(letter);
                });
            }

            overridden.put(changesLetters.tile, pos);

            tiles[pos.getRow()][pos.getCol()].placeTile(changesLetters.tile);
            Pane p = this.tiles[pos.getRow()][pos.getCol()].getDisplay();
            GridPane.setColumnIndex(p, pos.getCol());
            GridPane.setRowIndex(p, pos.getRow());
            board.getChildren().set(pos.getRow() * size + pos.getCol(), p);
        }
    }
}

/**
 * This class holds position information about a tile on the board
 */
class Position implements Comparable<Position> {

    public enum Direction {
        DOWN, ACROSS, BOTH
    }

    private int row;
    private int col;

    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }


    public Position(Position other) {
        this.row = other.row;
        this.col = other.col;
    }

    public int getCol() {
        return col;
    }

    public int getRow() {
        return row;
    }

    public Position transposed() {
        return new Position(this.col, this.row);
    }

    public void incrementCol() {
        this.col++;
    }

    public void incrementRow() {
        this.row++;
    }

    public void decrementCol() {
        this.col--; }

    public void decrementRow() {
        this.row--; }

    public int distance(Position other) {
        return (Math.abs(other.col - this.col) + Math.abs
                (other.row - this.row));
    }

    public Direction getDirection(Position other) {
        if (this.row - other.row != 0) {
            return Direction.DOWN;
        }
        if (this.col - other.col != 0) {
            return Direction.ACROSS;
        }

        return Direction.BOTH;
    }

    @Override
    public String toString() {
        return "{" + row + ", " + col + "}";
    }

    @Override
    public int hashCode() {
        return (row * 100 + col) * 97;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Position)) return false;

        Position other = (Position) obj;
        return (this.row == other.row && this.col == other.col);
    }

    @Override
    public int compareTo(Position o) {
        return (this.row * 100 + this.col) - (o.row * 100 + o.col);
    }
}
