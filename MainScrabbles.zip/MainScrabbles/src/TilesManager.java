/**
This class manages the tiles on the baord
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

public class TilesManager {
    private List<Tile> bag = new ArrayList<>();
    private Map<Character, Integer> valueMap = new HashMap<>();
    private Map<Character, Integer> countMap = new HashMap<>();

    public TilesManager() {}

    /**
     * Add the list of characters read in from the configuration file
     * into the tile manager
     * @param br the stream of input
     * @return boolean to initialize characters
     */
    public boolean initialize(BufferedReader br) {
        countMap.clear();
        valueMap.clear();
        bag.clear();
        try {
            String line;
            while ((line = br.readLine()) != null) {
                String[] array = line.split(" ");
                int value = Integer.parseInt(line.substring
                        (0,line.indexOf(":")));
                for (int i = 1; i < array.length; i++) {
                    int count = Integer.parseInt(
                            array[i].substring(1, array[i].indexOf(":")));
                    String[] chars = array[i].substring(array[i].
                            indexOf(":") + 1).split(",");
                    for (String s : chars) {
                        countMap.put(s.charAt(0), count);
                        valueMap.put(s.charAt(0), value);
                    }
                }
            }
        } catch (IOException e) {
            return false;
        }

        for (Map.Entry<Character, Integer> entry : countMap.entrySet()) {
            for (int i = 0; i < entry.getValue(); i++) {
                bag.add(new Tile(entry.getKey(),valueMap.get(entry.getKey())));
            }
        }
        return true;
    }

    /**
     * Calculate the value of a string
     * @param string the string whose value is to be checked
     * @return int for the value of the string
     */
    public int getValue(String string) {
        int sum = 0;
        for (int i = 0; i < string.length(); i++) {
            sum += getTileValue(string.charAt(i));
        }
        return sum;
    }

    /**
     * Get value of a single character from the map
     * @param character the letter whose value is to be returned
     * @return int a character
     */
    public int getTileValue(char character) {
        return valueMap.getOrDefault(character, 0);
    }

    /**
     * Fetch random tiles from the bag into the tray of a player
     * @param count the number of tiles to be drawn from bag
     * @return int random tils
     */
    public List<Tile> drawTiles(int count) {
        List<Tile> tray = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            //Draw each letter randomly
            Tile toAdd = drawOne();
            if (toAdd == null) {
                break;
            }
            tray.add(toAdd);
        }
        return tray;
    }

    public boolean isEmpty() {
        return bag.isEmpty();
    }

    /**Fetch one tile form the bag
     * @return Tile from bag
     */
    public Tile drawOne() {
        Random r = new Random();
        Tile toGet = null;
        if (bag.size() > 0) {
            int next = r.nextInt(bag.size());
            toGet = bag.get(next);
            bag.remove(next);
        }
        return toGet;
    }

    /**
     * Draw the given number of tiles from the bag
     * @param tray the tiles that the player currently has
     * @param count the number to be fetched
     * @return new tiles for tray
     */
    public List<Tile> redrawLetter(List<Tile> tray, int count) {
        List<Tile> newTray = drawTiles(count);
        bag.addAll(tray);
        return newTray;
    }

    /**Return a tile into the bag
     * @param t the tile to be returned
     */
    public void putBack(Tile t) {
        bag.add(t);
    }
}
