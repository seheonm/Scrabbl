/**
 * This class manages the players
 */

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.input.MouseDragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

import java.util.*;

public abstract class Player {
    protected TilesManager manager;
    protected Tray tray;
    protected Board board;

    protected HBox hand;

    public Player(TilesManager manager, Board board, List<Tile> tray) {
        this(manager, board);
        this.tray.setTiles(tray);
    }

    public Player(TilesManager manager, Board board) {
        this.manager = manager;
        this.board = board;
        tray = new Tray();
        hand = null;
    }

    /**
     * Finds if the hand is empty
     * @return boolean if hand is empty
     */
    public boolean isHandEmpty() {
        return tray.isEmpty();
    }

    public Player(TilesManager manager, Board board, HBox hand) {
        this(manager, board);
        this.hand = hand;
    }

    /**
     * Gets the leftover tile score
     * @return int of the leftover tile score
     */
    public int getLeftoverTileScore() {
        if (tray != null) {
            return tray.getTrayTotal();
        }
        return 0;
    }

    abstract public int takeTurn(Dictionary dict);

    abstract public String getLastWordPlayed();

    abstract public int getLastWordPlayedScore();

}

/**
 * This class manages the human player
 */

class HumanPlayer extends Player {

    private Map<Tile, Position> currentMove;
    private List<Position> currentPositions;
    private List<Position> otherPos;
    private boolean playMove;
    private boolean finishExchangeMove;
    private boolean exchanging;
    private String currentWord;
    private String lastWord;
    private int lastScore;
    private Position endPos;
    private Position startPos;


    public HumanPlayer(TilesManager manager, Board board, HBox hand) {
        super(manager, board, hand);
        hand.getChildren().clear();
        currentMove = new HashMap<>();
        currentPositions = new ArrayList<>();
        otherPos = new ArrayList<>();
        playMove = false;
        currentWord = null;
        startPos = null;
        endPos = null;
        finishExchangeMove = false;
        exchanging = false;
        tray.setTiles(manager.drawTiles(7));
        hand.getChildren().addAll(tray.getTileDisplays());
    }

    /**
     * Allow player to place their word on the board
     * @param dict the dictionary containing valid words
     * @return int for place of word
     */
    @Override
    public int takeTurn(Dictionary dict) {
        if (!tray.hasTiles()) {
            tray.setTiles(hand,
                    (GridPane)hand.getParent().getChildrenUnmodifiable().
                            get(1),
                    this::dropCallback,
                    this::returnedCallback);
        }

        if (playMove) {
            List<Tile> moves = new ArrayList<>(currentMove.keySet());
            board.playWord(currentWord,
                    new ArrayList<>(currentMove.keySet()),
                    startPos,
                    endPos);
            playMove = false;
            tray.removeTiles(moves);
            hand.getChildren().clear();
            tray.fillTray(manager);
            tray.setTiles(hand,
                    (GridPane)hand.getParent().getChildrenUnmodifiable().
                            get(1),
                    this::dropCallback,
                    this::returnedCallback);
            hand.getChildren().addAll(tray.getTileDisplays());
            startPos = null;
            endPos = null;
            lastWord = currentWord;
            currentWord = null;
            currentPositions.clear();
            currentMove.clear();
            return 0;
        } else if (finishExchangeMove) {
            if (!currentMove.isEmpty()) {
                board.resetPlaced();
                hand.getChildren().clear();
                hand.getChildren().addAll(tray.getTileDisplays());
            }

            finishExchangeMove = false;
            exchanging = false;
            tray.setTiles(hand, (GridPane)hand.getParent().
                    getChildrenUnmodifiable().get(1),
                    this::dropCallback, this::returnedCallback);
            currentPositions.clear();
            currentMove.clear();
            startPos = null;
            lastWord = null;
            currentWord = null;
            lastScore = 0;
            endPos = null;
            return 0;
        }
        return 1;
    }

    @Override
    public String getLastWordPlayed() {
        return lastWord;
    }

    @Override
    public int getLastWordPlayedScore() {
        return lastScore;
    }

    /**
     * CHeck if a play is valid
     * @param mouseEvent the event to be watched for when a player makes a move
     * @param dict the dictionary
     */
    public void attemptPlayMove(MouseEvent mouseEvent, Dictionary dict) {
        Button source = (Button)mouseEvent.getSource();
        if (source.getId().equals("playMove") && !exchanging) {
            if (currentMove.size() > 0) {
                if (isLegalMove(dict)) {
                    playMove = true;
                }
            } else {
                showMessage(Alert.AlertType.INFORMATION,
                        "Invalid Move","That is not a valid move","");
            }
        } else {
            finishExchangeMove = true;
        }

        mouseEvent.consume();
    }

    /**
     * Exchange a tile with one in the tile manager
     * @param mouseDragEvent the event to be checked for when a player
     *                      moves a tile
     */
    public void exchangeTile(MouseDragEvent mouseDragEvent) {
        if (!manager.isEmpty()) {
            exchanging = true;
            Pane p = (Pane) mouseDragEvent.getGestureSource();
            board.resetPlaced();
            GridPane board = (GridPane) hand.getParent().
                    getChildrenUnmodifiable().get(1);
            if (tray.contains(p)) {
                Tile t = tray.getTile(p);
                if (p.getParent() == null) {
                    UpdateTiles changesLetters = new UpdateTiles
                            (null, t, true);
                    board.fireEvent(changesLetters);
                    returnedCallback(t);
                    p.setTranslateX(0);
                    p.setTranslateY(0);
                } else {
                    p.setTranslateX(0);
                    p.setTranslateY(0);
                }
                hand.getChildren().clear();
                tray.replace(manager, t);
                hand.getChildren().addAll(tray.getTileDisplays());
            }
        } else {
            showMessage(Alert.AlertType.INFORMATION,
                    "Cannot exchange","No more tray to exchange with","");
            Pane p = (Pane) mouseDragEvent.getGestureSource();
            p.setTranslateX(0);
            p.setTranslateY(0);
        }

        mouseDragEvent.consume();
    }

    /**
     * Renew all the tiles in your tray
     * @param mouseDragEvent the event to be checked for when a player moves
     *                       a tile
     */
    public void resetTile(MouseDragEvent mouseDragEvent) {

        Pane p = (Pane)mouseDragEvent.getGestureSource();
        GridPane board =
                (GridPane)hand.getParent().getChildrenUnmodifiable().get(1);
        if (tray.contains(p)) {

            Tile t = tray.getTile(p);

            if (p.getParent().equals(board))  {
                UpdateTiles updateTiles = new UpdateTiles(null, t, true);
                board.fireEvent(updateTiles);
                returnedCallback(t);
                p.setTranslateX(0);
                p.setTranslateY(0);
                hand.getChildren().add(p);
            }
        }

        mouseDragEvent.consume();
    }

    /**
     * Display message to the user
     * @param type type of alert
     * @param title title of the alert
     * @param header header message of the alert
     * @param content content of the alert
     */
    private void showMessage(Alert.AlertType type, String title,
                             String header, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    /**
     * Check if a move is valid
     * @param dict the dictionary
     * @return boolean if the move is valid
     */
    private boolean isLegalMove(Dictionary dict) {
        currentPositions = new ArrayList<>(currentMove.values());
        Collections.sort(currentPositions);
        startPos = currentPositions.get(0);
        endPos = currentPositions.get(currentPositions.size() - 1);
        Position.Direction dir = startPos.getDirection(endPos);

        if (dir == Position.Direction.BOTH && !startPos.equals(endPos)) {
            showMessage(Alert.AlertType.INFORMATION,
                    "Invalid Move","That is not a valid move","");
            return false;
        }

        if (dir == Position.Direction.BOTH) {
            if (checkForPrefix(startPos, Position.Direction.ACROSS) != 0) {
                dir = Position.Direction.ACROSS;
                checkForSuffix(startPos, dir);
            } else if(checkForSuffix(startPos,Position.Direction.ACROSS) != 0){

            } else if (checkForPrefix(startPos, Position.Direction.DOWN) != 0){
                dir = Position.Direction.DOWN;
                checkForSuffix(startPos, dir);
            } else {
                checkForSuffix(startPos, Position.Direction.DOWN);
            }
        } else {
            checkForPrefix(startPos, dir);
            checkForSuffix(endPos, dir);
            checkForInfix(startPos, endPos, dir);
        }

        Collections.sort(currentPositions);
        Set<Position> anchors = board.getPotentialAnchorSquares();
        boolean hasAnchorSomewhere = false;
        Position prev = null;
        for (Position p : currentPositions) {
            if (anchors.contains(p)) {
                hasAnchorSomewhere = true;
            }
            if (prev != null) {
                if (p.distance(prev) > 1) {
                    currentPositions.removeAll(otherPos);
                    otherPos.clear();
                    showMessage(Alert.AlertType.INFORMATION,
                            "Invalid Move","That is not a valid move",
                            "Move must be all down or all across");
                    return false;
                }
            }
            prev = p;
        }

        if (!hasAnchorSomewhere) {
            currentPositions.removeAll(otherPos);
            otherPos.clear();
            showMessage(Alert.AlertType.INFORMATION,
                    "Invalid Move","That is not a valid move",
                    "Move must start from another letter");
            return false;
        }

        startPos = currentPositions.get(0);
        endPos = currentPositions.get(currentPositions.size() - 1);

        dir = startPos.getDirection(endPos);
        currentWord = "";
        Map<Integer, Set<Character>> crossChecks;
        StringBuilder sb = new StringBuilder();
        switch (dir) {
            case ACROSS:
                crossChecks = board.generateCrossChecks(dict);
                for (int i = startPos.getCol(); i <= endPos.getCol(); i++) {
                    Set<Character> cross =
                            crossChecks.get(startPos.getRow() *
                                    board.getSize() + i);
                    if (cross != null &&
                            !cross.contains(board.getTile(startPos.getRow(), i)
                                    .letter)) {
                        currentPositions.removeAll(otherPos);
                        otherPos.clear();
                        showMessage(Alert.AlertType.INFORMATION,
                                "Invalid Move","That is not a valid move",
                                "All sub words are not a word");
                        return false;
                    }
                    sb.append(board.getTile(startPos.getRow(), i).letter);
                }
                lastScore = board.getValue(sb.toString(),
                        new ArrayList<>(currentMove.keySet()), startPos);
                break;
            case DOWN:
                board.transpose();

                crossChecks = board.generateCrossChecks(dict);
                for (int i = startPos.getRow(); i <= endPos.getRow(); i++) {
                    Set<Character> cross =
                            crossChecks.get(startPos.getCol() * board.getSize() + i);
                    if (cross != null &&
                            !cross.contains(board.getTile(startPos.getCol(), i)
                                    .letter)) {
                        currentPositions.removeAll(otherPos);
                        otherPos.clear();
                        showMessage(Alert.AlertType.INFORMATION,
                                "Invalid Move","That is not a valid move",
                                "All sub words are not a word");
                        return false;
                    }
                    sb.append(board.getTile(startPos.getCol(), i)
                            .letter);
                }
                lastScore = board.getValue(sb.toString(),
                        new ArrayList<>(currentMove.keySet()),
                        startPos.transposed());
                board.transpose();
                break;
        }
        currentWord = sb.toString();
        if (!dict.search(currentWord)) {
            currentPositions.removeAll(otherPos);
            otherPos.clear();
            lastScore = -1;
            showMessage(Alert.AlertType.INFORMATION,
                    "Invalid Word","That is not a valid word",
                    "The word you are trying to play isn't in the dictionary");
            return false;
        }

        otherPos.clear();
        return true;
    }

    /**Checks to see if any tray that were already on the board
     * needs to be added to current positions
     * @param startPos start position
     * @param endPos end position
     * @param dir direction of play
     */
    private void checkForInfix(Position startPos, Position endPos,
                               Position.Direction dir) {
        switch (dir) {
            case ACROSS:
                for (int i = startPos.getCol(); i <= endPos.getCol(); i++) {
                    if (!board.isEmpty(startPos.getRow(), i)) {
                        otherPos.add(new Position(startPos.getRow(), i));
                        currentPositions.add(
                                new Position(startPos.getRow(), i));
                    }
                }
                break;
            case DOWN:
                for (int i = startPos.getRow(); i <= endPos.getRow(); i++) {
                    if (!board.isEmpty(i, startPos.getCol())) {
                        otherPos.add(new Position(i, startPos.getCol()));
                        currentPositions.add(
                                new Position(i, startPos.getCol()));
                    }
                }
                break;
        }
    }

    /**
     * Checks if any positions after endPos that were already on the board
     *  need to be added
     * @param endPos the end position
     * @param dir direction of play
     * @return int to check positions when on board
     */
    private int checkForSuffix(Position endPos, Position.Direction dir) {
        Position current;
        int returnVal = currentPositions.size();
        switch (dir) {
            case ACROSS:
                current = new Position(endPos.getRow(),
                        endPos.getCol() + 1);
                while (current.getCol() < board.getSize()
                        && !board.isEmpty(current.getRow(), current.getCol())){
                    otherPos.add(
                            new Position(current.getRow(), current.getCol()));
                    currentPositions.add(
                            new Position(current.getRow(), current.getCol()));
                    current.incrementCol();
                }
                break;
            case DOWN:
                current = new Position(endPos.getRow()+1,endPos.getCol());
                while (current.getRow() < board.getSize()
                        && !board.isEmpty(current.getRow(), current.getCol())){
                    otherPos.add(
                            new Position(current.getRow(), current.getCol()));
                    currentPositions.add(
                            new Position(current.getRow(), current.getCol()));
                    current.incrementRow();
                }
                break;
        }
        return (Math.abs(returnVal - currentPositions.size()));
    }

    /**
     * Checks if any positions before current position that were already on
     * the board
     * need to be added
     * @param start start position
     * @param dir direction of play
     * @return int to check positions before
     */
    private int checkForPrefix(Position start, Position.Direction dir) {
        Position current;
        int returnVal = currentPositions.size();
        switch (dir) {
            case ACROSS:
                current = new Position(start.getRow(), start.getCol() - 1);
                while (current.getCol() >= 0
                        && !board.isEmpty(current.getRow(), current.getCol())){
                    otherPos.add(
                            new Position(current.getRow(), current.getCol()));
                    currentPositions.add(
                            new Position(current.getRow(), current.getCol()));
                    current.decrementCol();
                }
                break;
            case DOWN:
                current = new Position(start.getRow() - 1, start.getCol());
                while (current.getRow() >= 0
                        && !board.isEmpty(current.getRow(), current.getCol())){
                    otherPos.add(
                            new Position(current.getRow(), current.getCol()));
                    currentPositions.add(
                            new Position(current.getRow(), current.getCol()));
                    current.decrementRow();
                }
                break;
        }
        return (Math.abs(returnVal - currentPositions.size()));
    }

    /**
     * Remove a tile from the board after invalid move
     * @param returned the tile to be return ed to the player
     */
    private void returnedCallback(Tile returned) {
        currentMove.remove(returned);
    }

    /**
     * Unplace a tile from the board after drop
     * @param dropped invalid tile dropped
     * @param pos position it originally was
     */
    private void dropCallback(Tile dropped, Position pos) {

        if (!currentMove.containsValue(pos)
                && pos.getCol() >= 0 && pos.getCol() < board.getSize()
                && pos.getRow() >= 0 && pos.getRow() < board.getSize()) {
            currentMove.put(dropped, pos);
        }
    }
}

/**
 * This class manages the computer player
 */

class ComputerPlayer extends Player {

    private String highestScoringLeftOfAnchor;
    private String highestScoringWord;
    private int highestScoring;
    private Position highestAnchorPos;
    private Position highestStartPos;
    private Set<String> legalMoves;
    private List<Tile> currentMove;
    private List<Tile> highestMove;
    private Position currentAnchor;
    private Position currentStartPos;
    private Position currentEndPos;
    private Position highestEndPos;
    private String leftOfAnchor;

    public ComputerPlayer(TilesManager manager, Board board, List<Tile> tray) {
        super(manager, board, tray);
        legalMoves = new HashSet<>();
        currentMove = new ArrayList<>();
        highestMove = new ArrayList<>();
        hand = null;
        leftOfAnchor = null;
        resetValues();
    }

    public ComputerPlayer(TilesManager manager, Board board, HBox hand) {
        super(manager, board, hand);
        hand.getChildren().clear();
        tray.setTiles(manager.drawTiles(7));
        legalMoves = new HashSet<>();
        currentMove = new ArrayList<>();
        highestMove = new ArrayList<>();
        tray.hideTray();
        hand.getChildren().addAll(tray.getTileDisplays());
        resetValues();
    }

    /**
     * Resets all the values
     */
    private void resetValues() {
        legalMoves.clear();
        highestStartPos = null;
        highestAnchorPos = null;
        highestScoringWord = null;
        highestScoringLeftOfAnchor = null;
        leftOfAnchor = null;
        currentMove.clear();
        highestMove.clear();
        currentAnchor = null;
        currentStartPos = null;
        currentEndPos = null;
        highestEndPos = null;
        highestScoring = 0;
    }

    @Override
    public String getLastWordPlayed() {
        if (highestScoringLeftOfAnchor != null) {
            return highestScoringLeftOfAnchor + highestScoringWord;
        } else {
            return highestScoringWord;
        }
    }

    @Override
    public int getLastWordPlayedScore() {
        return highestScoring;
    }

    /**
     * Allows the computer to search for a move
     * @param dict dictionary
     * @return int for a move
     */
    @Override
    public int takeTurn(Dictionary dict) {
        resetValues();
        calcMoves(board, dict);
        board.transpose();
        calcMoves(board, dict);
        board.transpose();
        if (legalMoves.size() == 0) {
            tray.setTiles(manager.redrawLetter(tray.getTiles(), 7));
            return 0;
        }

        List<Tile> moves = new ArrayList<>(highestMove);
        board.playWord(highestScoringWord, highestMove, highestStartPos,
                highestEndPos);
        tray.removeTiles(moves);
        if (hand != null) {
            hand.getChildren().clear();
        }
        if (!manager.isEmpty()) {
            tray.fillTray(manager);
            tray.hideTray();
        }
        if (hand != null) {
            hand.getChildren().addAll(tray.getTileDisplays());
        }

        return 0;
    }

    /**
     * Get all possible moves that can be validly made
     * @param board the board class which manages the board
     * @param dict the dictionary
     */
    private void calcMoves(Board board, Dictionary dict) {
        Map<Integer, Set<Character>> crossChecks =
                board.generateCrossChecks(dict);
        if (crossChecks == null) {
            crossChecks = new HashMap<>();
        }
        Set<Position> anchors = board.getPotentialAnchorSquares();
        int count;
        int currentCol;
        for (Position p : anchors) {
            count = 0;
            currentCol = p.getCol() - 1;
            while (currentCol >= 0
                    && !anchors.contains(new Position(p.getRow(),currentCol))){
                count++;
                currentCol--;
            }
            count = Math.min(tray.size(), count);
            currentAnchor = new Position(p);
            currentStartPos = new Position(p);
            currentEndPos = new Position(p);
            if (count > 0 && !board.isEmpty(p.getRow(), p.getCol() - 1)) {
                StringBuilder sb = new StringBuilder();
                currentCol = p.getCol() - 1;
                while (count > 0 && !board.isEmpty(p.getRow(), currentCol)) {
                    sb.insert(0, board.getTile(p.getRow(), currentCol).letter);
                    count--;
                    currentCol--;
                }
                if (dict.getRootNode().transition(sb.toString()) != null) {
                    leftOfAnchor = sb.toString();
                    extendRight("",dict.getRootNode().transition(leftOfAnchor),
                            p, board, crossChecks);
                }
            } else {
                leftOfAnchor = null;
                leftPart("", dict.getRootNode(), count, p, board, crossChecks);
            }
        }
    }

    /**
     * Check if a word can be made by adding onto the left part of an acnhor point
     * @param partialWord the left part of the word
     * @param n the entire word
     * @param limit the max characters to be contained
     * @param anchor the connection to words already played
     * @param board the board object
     * @param crossChecks the set of charcaters to be cross checked against
     */
    private void leftPart(String partialWord, Word n,int limit,Position anchor,
                          Board board,Map<Integer,Set<Character>> crossChecks){
        if (currentStartPos.getCol() >= 0) {
            extendRight(partialWord, n, anchor, board, crossChecks);
            if (limit > 0) {
                for (Map.Entry<Character, Word> entry :
                        n.getCharacterNodeMap().entrySet()) {
                    char key = entry.getKey();
                    if (tray.isInTray(key)) {
                        Tile t = tray.removeTile(key);
                        if (t.isBlank()) {
                            t.setLetter(key);
                        }
                        currentMove.add(t);
                        currentStartPos = new Position(currentStartPos.getRow(),
                                currentStartPos.getCol() - 1);

                        leftPart(partialWord + key, n.transition(key),
                                limit - 1, anchor, board, crossChecks);
                        currentStartPos = new Position(currentStartPos.getRow(),
                                currentStartPos.getCol() + 1);
                        if (t.isBlank()) {
                            t.setLetter('*');
                        }

                        currentMove.remove(t);
                        tray.addTile(t);
                    }
                }
            }
        }
    }

    /**
     * CHeck if a word can be made by adding letters onto the right side from
     * an anchor point
     * @param partialWord the part to be added
     * @param n the whole word
     * @param square starting position of word
     * @param board the board object
     * @param crossChecks the set of characters to be checked against
     */
    private void extendRight(String partialWord, Word n, Position square,
                             Board board,
                             Map<Integer, Set<Character>> crossChecks) {

        if (square.getCol() >= board.getSize()) {
            if (n.isWord()) {
                currentEndPos = new Position(square.getRow(),
                        square.getCol() - 1);
                legalMove(partialWord, currentAnchor, board);
            }
            return;
        }

        if (board.isEmpty(square.getRow(), square.getCol())) {
            if (n.isWord()) {
                currentEndPos = new Position(square.getRow(),
                        square.getCol() - 1);
                legalMove(partialWord, currentAnchor, board);
            }
            for (Map.Entry<Character, Word> entry :
                    n.getCharacterNodeMap().entrySet()) {
                char key = entry.getKey();
                boolean inCross = false;
                if (tray.isInTray(key)) {
                    Set<Character> crossSet =
                            crossChecks.get(square.getRow() * board.getSize()
                                    + square.getCol());
                    if (crossSet == null) {
                        inCross = true;
                    } else {
                        if (crossSet.contains(key)) {
                            inCross = true;
                        }
                    }
                    if (inCross) {
                        Tile t = tray.removeTile(key);
                        currentMove.add(t);

                        if (t.isBlank()) {
                            t.setLetter(key);
                        }

                        extendRight(partialWord + key, n.transition(key),
                                new Position(square.getRow(),
                                        square.getCol() + 1),
                                board, crossChecks);
                        if (t.isBlank()) {
                            t.setLetter('*');
                        }
                        currentMove.remove(t);
                        tray.addTile(t);
                    }
                }
            }
        }

        else {
            Tile t = board.getTile(square.getRow(), square.getCol());
            if (n.getCharacterNodeMap().containsKey(t.letter)) {
                extendRight(partialWord + t.letter,
                        n.transition(t.letter),
                        new Position(square.getRow(), square.getCol() + 1),
                        board, crossChecks);
            }
        }
    }

    /**
     * CHeck if the move is legal
     * @param word the word made
     * @param anchorPos the position it joins the board
     * @param board the board object
     */
    private void legalMove(String word, Position anchorPos, Board board) {
        if (word.length() < 2) {
            return;
        }

        int i;
        for (i = currentStartPos.getCol(); i <= currentEndPos.getCol(); i++) {
            if (anchorPos.getCol() == i && anchorPos.getRow() ==
                    currentStartPos.getRow()) {
                break;
            }
        }
        if (i > currentEndPos.getCol()) {
            return;
        }

        if (highestScoring == 0) {
            highestMove.clear();
            highestScoringWord = word;
            highestMove.addAll(currentMove);
            highestScoringLeftOfAnchor = leftOfAnchor;

            if (currentEndPos.getCol() !=
                    currentStartPos.getCol() + word.length() - 1) {
                currentEndPos = new Position(currentEndPos.getRow(),
                        currentStartPos.getCol() + word.length() - 1);
            }

            getPositions(anchorPos, board);
            highestScoring = board.getValue(word, currentMove, currentStartPos)
                    + (leftOfAnchor == null ? 0 :
                    manager.getValue(leftOfAnchor));
        }
        else {
            if (currentEndPos.getCol() !=
                    currentStartPos.getCol() + word.length() - 1) {
                currentEndPos = new Position(currentEndPos.getRow(),
                        currentStartPos.getCol() + word.length() - 1);
            }
            int score = board.getValue(word, currentMove, currentStartPos)
                    + (leftOfAnchor == null ? 0 :
                    manager.getValue(leftOfAnchor));
            if (score > highestScoring) {
                highestMove.clear();
                getPositions(anchorPos, board);
                highestScoringWord = word;
                highestScoring = score;
                highestMove.addAll(currentMove);
                highestScoringLeftOfAnchor = leftOfAnchor;
            }
        }
        if (leftOfAnchor != null) {
            legalMoves.add(leftOfAnchor + word);
        } else {
            legalMoves.add(word);
        }
    }

    /**Adjust the positions according to whether the board is transposed
     * @param anchorPos the position it joined the already played words
     * @param board the board object
     */
    private void getPositions(Position anchorPos, Board board) {
        if (board.isTransposed()) {
            highestEndPos = currentEndPos.transposed();
            highestAnchorPos = anchorPos.transposed();
            highestStartPos = currentStartPos.transposed();
        } else {
            highestStartPos = new Position(currentStartPos);
            highestEndPos = new Position(currentEndPos);
            highestAnchorPos = new Position(anchorPos);
        }
    }
}
