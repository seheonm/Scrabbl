/**
 * Marina Seheon
 * Project 3 CS351L
 * This is the class that runs the command line scrabble
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CommandLineSolver {
    private Player cpuPlayer;
    private Dictionary dict;
    private Board board;
    private TilesManager manager;
    private final static String LETTER_DIS  =
            "default_letter_distributions.txt";


    /**
     * Constructor to read in the data about the board and initialize the
     * variables
     * @param br the reader that has a stream of data to be used
     */
    public CommandLineSolver(BufferedReader br) {
        System.out.println("Welcome to our scrabble game\n");
        dict = Dictionary.createDict(
                Dictionary.DictionaryType.DAWG);
        dict.insert(br);
        board = new Board();
        cpuPlayer = null;
        manager = new TilesManager();
        BufferedReader letters = null;
        try {
            letters = new BufferedReader(
                    new FileReader(LETTER_DIS));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        manager.initialize(letters);
        try {
            letters.close();
            br.close();
        } catch (IOException e) {
            System.out.println("Could not close files");
        }
    }

    /**
     * Driver program to run the code
     * @param args command line arguments
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("You must provide the path to the dictionary" +
                    " file as a command line argument");
            return;
        }
        CommandLineSolver commandLineSolver;
        try {
            commandLineSolver = new CommandLineSolver(
                    new BufferedReader(
                            new FileReader(new File(args[0]))));
        } catch (IOException e) {
            System.out.println("Could not read dictionary file");
            return;
        }
        Scanner in = new Scanner(System.in);

        do {
            System.out.println("Enter board and tray configuration:");
            long start = System.currentTimeMillis();
            if (!commandLineSolver.findBest(in)) {
                System.out.println("Could not find best, " +
                        "board file is incorrect");
            } else {
                long end = System.currentTimeMillis();
                System.out.println("Time to find move: "
                        + (end - start) + "ms");
            }
            System.out.print("Do you want to go again? (y/n): ");
            if(!in.nextLine().equalsIgnoreCase("y")){
                break;
            }
        }while (true);
    }

    /**
     * Compute all possible moves and get the one with the best score
     * @param in the scanner that has the link to the data to be read in
     * @return boolean for the best moves
     */
    private boolean findBest(Scanner in) {
        if (!board.initialize(in, manager)) {
            return false;
        }
        String lastLine = in.nextLine();
        lastLine = lastLine.toUpperCase();
        List<Tile> tray = new ArrayList<>();
        for (int i = 0; i < lastLine.length(); i++) {
            tray.add(new Tile(lastLine.charAt(i),
                    manager.getTileValue(lastLine.charAt(i))));
        }
        cpuPlayer = new ComputerPlayer(manager, board, tray);
        cpuPlayer.takeTurn(dict);
        System.out.println(board);
        System.out.println("Word score: " +
                cpuPlayer.getLastWordPlayedScore());
        System.out.println("Word played: " +
                cpuPlayer.getLastWordPlayed());
        return true;
    }
}